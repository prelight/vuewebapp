/*
 * Copyright (c) 2016 Sony Network Communications Inc. All rights reserved.
 */

package com.sony.csx.bda.actionlog;

import com.sony.csx.bda.actionlog.format.ActionLog;
import com.sony.csx.bda.actionlog.format.CSXActionLogField;

import java.util.List;

public class TestActionLog {

    public static class ServiceInfo extends ActionLog.ServiceInfo<ServiceInfo> {
        private static final CSXActionLogField.Restriction[] properties;

        static {
            properties = new CSXActionLogField.Restriction[]{
                    new CSXActionLogField.Restriction(ServiceInfoKey.loginId, CSXActionLogField.Type.STRING, false, null, 0, 10, 0, 0, 0, 0)
            };
        }

        public ServiceInfo() {
            super(properties);

        }

        public TestActionLog.ServiceInfo setLoginId(String loginId) {
            setObject(ServiceInfoKey.loginId.keyName(), loginId);
            return this;
        }

        public String getLoginId() {
            return getObjectForKey(ServiceInfoKey.loginId.keyName());
        }

        enum ServiceInfoKey implements Key {
            loginId {
                @Override
                public String keyName() {
                    return "loginId";
                }
            }
        }
    }

    public static class Setting extends ActionLog.Action {
        private static final int TYPE_ID = 2004;

        private static final CSXActionLogField.Restriction[] properties = {
                new CSXActionLogField.Restriction(SettingKey.gender, CSXActionLogField.Type.STRING, false, null, 0, 5, 0, 0, 0, 0),
                new CSXActionLogField.Restriction(SettingKey.yearOfBirth, CSXActionLogField.Type.STRING, false, "^[0-9]{4}$", 0, 0, 0, 0, 0, 0)
        };

        public Setting() {
            super(properties);
        }

        @Override
        public int getActionTypeId() {
            return TYPE_ID;
        }

        public Setting setGender(String gender) {
            this.setObject(SettingKey.gender.keyName(), gender);
            return this;
        }

        public Setting setYearOfBirth(String yearOfBirth) {
            this.setObject(SettingKey.yearOfBirth.keyName(), yearOfBirth);
            return this;
        }

        enum SettingKey implements Key {
            gender {
                @Override
                public String keyName() {
                    return "gender";
                }
            },
            yearOfBirth {
                @Override
                public String keyName() {
                    return "yearOfBirth";
                }
            }
        }

    }

    public static class ContentInfoSample extends ActionLog.ContentInfo {
        private static final int TYPE_ID = 5555;

        public ContentInfoSample() {
            super(properties);
        }

        private static final CSXActionLogField.Restriction[] properties = {
                new CSXActionLogField.Restriction(ContentKey.dummy1, CSXActionLogField.Type.STRING, false, null, 1, 20, 0, 0, 0, 0),
                new CSXActionLogField.Restriction(ContentKey.dummy2, CSXActionLogField.Type.STRING, false, null, 0, 20, 0, 0, 0, 0)
        };

        @Override
        public int getTypeId() {
            return TYPE_ID;
        }

        public TestActionLog.ContentInfoSample setDummy(String dummy) {
            this.setObject(ContentKey.dummy1.keyName(), dummy);
            return this;
        }

        public TestActionLog.ContentInfoSample setDummy2(String dummy2) {
            this.setObject(ContentKey.dummy2.keyName(), dummy2);
            return this;
        }

        enum ContentKey implements Key {
            dummy1 {
                @Override
                public String keyName() {
                    return "dummy1";
                }
            },
            dummy2 {
                @Override
                public String keyName() {
                    return "dummy2";
                }
            }
        }

    }

    public static class TestDictionary extends ActionLog.Dictionary<TestDictionary> {
        private static final Restriction[] RESTRICTIONS;

        static {

            RESTRICTIONS = new Restriction[]{
                    new CSXActionLogField.RestrictionString(TestDictionaryKey.ID, true, null, Integer.MIN_VALUE, Integer.MAX_VALUE),
                    new CSXActionLogField.RestrictionString(TestDictionaryKey.VALUE, false, null, Integer.MIN_VALUE, Integer.MAX_VALUE),
                    new CSXActionLogField.RestrictionString(TestDictionaryKey.NAME, false, null, 1, 5)
            };
        }

        public TestDictionary() {
            super(RESTRICTIONS);
        }

        public TestDictionary(Restriction[] restrictions) {
            super(restrictions);
        }

        public TestDictionary setId(String id) {
            setObject(TestDictionaryKey.ID.keyName(), id);
            return this;
        }

        public TestDictionary setValue(String value) {
            setObject(TestDictionaryKey.VALUE.keyName(), value);
            return this;
        }

        public TestDictionary setName(String name) {
            setObject(TestDictionaryKey.NAME.keyName(), name);
            return this;
        }

        enum TestDictionaryKey implements Key {
            ID {
                @Override
                public String keyName() {
                    return "id";
                }
            },
            VALUE {
                @Override
                public String keyName() {
                    return "value";
                }
            },
            NAME {
                @Override
                public String keyName() {
                    return "name";
                }
            }

        }
    }

    public static class ActionTemplate extends ActionLog.Action {

        public ActionTemplate(CSXActionLogField.Restriction[] properties) {
            super(properties);
        }

        @Override
        public int getActionTypeId() {
            return 0;
        }
    }

    public static class ActionSample extends ActionLog.Action<ActionSample> {
        private static final CSXActionLogField.Restriction[] restrictions;
        private static final CSXActionLogField.Restriction key1;
        private static final CSXActionLogField.Restriction key2;
        private static final CSXActionLogField.Restriction key3;
        private static final CSXActionLogField.Restriction key4;
        private static final CSXActionLogField.Restriction key5;
        private static final CSXActionLogField.Restriction key6;
        private static final CSXActionLogField.Restriction key7;
        private static final CSXActionLogField.Restriction key8;
        private static final CSXActionLogField.Restriction key9;

        static {
            key1 = new CSXActionLogField.RestrictionString(Keys.KEY1, false, null, 0, 10);
            key2 = new CSXActionLogField.RestrictionInteger(Keys.KEY2, false, 1, 10);
            key3 = new CSXActionLogField.RestrictionLong(Keys.KEY3, false, 1, 10);
            key4 = new CSXActionLogField.RestrictionDouble(Keys.KEY4, false, 1.1, 10.1);
            key5 = new CSXActionLogField.RestrictionArrayString(Keys.KEY5, false, null, 1, 10, 1, 5);
            key6 = new CSXActionLogField.RestrictionArrayInteger(Keys.KEY6, false, 1, 10, 1, 5);
            key7 = new CSXActionLogField.RestrictionArrayLong(Keys.KEY7, false, 1, 10, 1, 5);
            key8 = new CSXActionLogField.RestrictionArrayDouble(Keys.KEY8, false, 1.1, 10.1, 1, 5);
            key9 = new CSXActionLogField.RestrictionBoolean(Keys.KEY9, true);

            restrictions = new CSXActionLogField.Restriction[]{
                    key1,
                    key2,
                    key3,
                    key4,
                    key5,
                    key6,
                    key7,
                    key8,
                    key9,
            };
        }

        public ActionSample() {
            super(restrictions);
        }

        @Override
        public int getActionTypeId() {
            return 10000;
        }

        public ActionSample setKey1(String value) {
            this.setObject(Keys.KEY1.keyName(), value);
            return this;
        }

        public ActionSample setKey2(Integer value) {
            this.setObject(Keys.KEY2.keyName(), value);
            return this;
        }

        public ActionSample setKey3(Long value) {
            this.setObject(Keys.KEY3.keyName(), value);
            return this;
        }

        public ActionSample setKey4(Double value) {
            this.setObject(Keys.KEY4.keyName(), value);
            return this;
        }

        public ActionSample setKey5(List<String> value) {
            this.setObject(Keys.KEY5.keyName(), value);
            return this;
        }

        public ActionSample setKey6(List<Integer> value) {
            this.setObject(Keys.KEY6.keyName(), value);
            return this;
        }

        public ActionSample setKey7(List<Long> value) {
            this.setObject(Keys.KEY7.keyName(), value);
            return this;
        }

        public ActionSample setKey8(List<Double> value) {
            this.setObject(Keys.KEY8.keyName(), value);
            return this;
        }

        public ActionSample setKey9(Boolean value) {
            this.setObject(Keys.KEY9.keyName(), value);
            return this;
        }

        private enum Keys implements Key {
            KEY1 {
                @Override
                public String keyName() {
                    return "key1";
                }

                @Override
                public CSXActionLogField.Restriction getRestriction() {
                    return key1;
                }
            },
            KEY2 {
                @Override
                public String keyName() {
                    return "key2";
                }

                @Override
                public CSXActionLogField.Restriction getRestriction() {
                    return key2;
                }
            },
            KEY3 {
                @Override
                public String keyName() {
                    return "key3";
                }

                @Override
                public CSXActionLogField.Restriction getRestriction() {
                    return key3;
                }
            },
            KEY4 {
                @Override
                public String keyName() {
                    return "key4";
                }

                @Override
                public CSXActionLogField.Restriction getRestriction() {
                    return key4;
                }
            },
            KEY5 {
                @Override
                public String keyName() {
                    return "key5";
                }

                @Override
                public CSXActionLogField.Restriction getRestriction() {
                    return key5;
                }
            },
            KEY6 {
                @Override
                public String keyName() {
                    return "key6";
                }

                @Override
                public CSXActionLogField.Restriction getRestriction() {
                    return key6;
                }
            },
            KEY7 {
                @Override
                public String keyName() {
                    return "key7";
                }

                @Override
                public CSXActionLogField.Restriction getRestriction() {
                    return key7;
                }
            },
            KEY8 {
                @Override
                public String keyName() {
                    return "key8";
                }

                @Override
                public CSXActionLogField.Restriction getRestriction() {
                    return key8;
                }
            },
            KEY9 {
                @Override
                public String keyName() {
                    return "key9";
                }

                @Override
                public CSXActionLogField.Restriction getRestriction() {
                    return key9;
                }
            };

            abstract public CSXActionLogField.Restriction getRestriction();

        }

    }
}
